import { Component, OnInit } from '@angular/core';

import { CurrencyService } from '../shared/currency.service';
import { Currency } from '../shared/currency';

@Component({
  selector: 'app-currency-list',
  templateUrl: './currency-list.component.html',
  styleUrls: ['./currency-list.component.css']
})
export class CurrencyListComponent implements OnInit {
  title: string = 'Currency List';
  listFilter: string;
  favoriteFilter: string = 'all';
  showImage: boolean = false;
  imageWidth: number = 50;
  imageMargin: number = 2;
  errorMessage: string;

  currencies: Currency[];

constructor(private currencyService: CurrencyService) { }

  ngOnInit() {
    this.getCurrencies();
  }

  onCurrencyAdded(currencyAdded: boolean) {
    alert('onCurrencyAdded');
  }

  getCurrencies() : void {
      this.currencyService.geCurrencies().
        then(currencies => this.currencies = currencies).
        catch(err => this.errorMessage = <any>err);
  }

  toggleImage(): void {
      this.showImage = !this.showImage;
  }

  addCurrency(currency: Currency) {
    alert('addCurrency clicked!');
  }

}
