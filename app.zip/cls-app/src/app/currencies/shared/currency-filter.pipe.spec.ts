import { CurrencyFilterPipe } from './currency-filter.pipe';

describe('CurrencyFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new CurrencyFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
