export class Currency {
  id: number;
  name: string;
  price: number;
  change: string;
  pChange: string;
  dayRange: string;
  weekRange: string;
  imageUrl: string;
  favorite: boolean;
}
