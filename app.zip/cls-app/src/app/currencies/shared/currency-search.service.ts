import { Injectable } from '@angular/core';
import { Http }       from '@angular/http';

import { Observable }     from 'rxjs/Observable';
import 'rxjs/add/operator/map';

import { Currency } from './currency';

@Injectable()
export class CurrencySearchService {
  private currenciesUrl = 'api/currenciesCatalog';  // URL to web api

  constructor(private http: Http) { }

  search(term: string): Observable<Currency[]> {
    return this.http.get(`${this.currenciesUrl}/?name=${term}`)
            .map(response => response.json().data as Currency[]);
  }
  
}
