import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { Currency } from './shared/currency'; // oootemp should it be in providers or declarations?
import { CurrencyService } from './shared/currency.service';
import { CurrencySearchService } from './shared/currency-search.service';

import { CurrencyComponent } from './currency/currency.component';
import { CurrencyListComponent } from './currency-list/currency-list.component';
import { CurrenciesComponent } from './currencies.component';
import { CurrencyFilterPipe } from './shared/currency-filter.pipe';
import { CurrencySearchComponent } from './currency-search/currency-search.component';

const routes: Routes = [
  { path: 'currencies/:id', component: CurrencyComponent },
  { path: 'currencies',     component: CurrenciesComponent }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    RouterModule.forRoot(routes)
  ],
  declarations: [
    CurrencyComponent,
    CurrencyListComponent,
    CurrenciesComponent,
    CurrencyFilterPipe,
    CurrencySearchComponent
  ],
  providers: [
    CurrencyService,
    CurrencySearchService
  ]
})
export class CurrenciesModule { }
