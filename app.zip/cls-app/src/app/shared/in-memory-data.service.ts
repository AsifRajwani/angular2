import { InMemoryDbService } from 'angular-in-memory-web-api';
import { Currency } from '../currencies/shared/currency'

export class InMemoryDataService implements InMemoryDbService {
  createDb() {
    let currencies: Currency[] = [
      {id: 11, name: 'EUR/USD', price: 1.0622, change: '+0.0005', pChange: '+0.0509%', dayRange: '1.0604 - 1.0630', weekRange: '1.0540 - 1.1707', imageUrl: '', favorite: false},
      {id: 12, name: 'AUD/USD', price: 0.7574, change: '+0.0005', pChange: '+0.0674%', dayRange: '0.7555 - 0.7582', weekRange: '0.6828 - 0.7834', imageUrl: '', favorite: false},
      {id: 13, name: 'GBP/USD', price: 1.2527, change: '+0.0021', pChange: '+0.1671%', dayRange: '1.2498 - 1.2534', weekRange: '1.2498 - 1.5817', imageUrl: '', favorite: false},
      {id: 14, name: 'USD/JPY', price: 108.6370, change: '-0.4720', pChange: '-0.4326%', dayRange: '108.5730 - 109.2260', weekRange: '99.5730 - 118.6470', imageUrl: '', favorite: false},
      {id: 15, name: 'EUR/JPY', price: 115.3920, change: '-0.4610', pChange: '-0.3979%', dayRange: '115.3290 - 116.0170', weekRange: '109.5852 - 139.3154', imageUrl: '', favorite: false},
      {id: 16, name: 'EUR/GBP', price: 0.8478, change: '-0.0010', pChange: '-0.1225%', dayRange: '0.8472 - 0.8495', weekRange: '0.6936 - 0.8495', imageUrl: '', favorite: false},
      {id: 17, name: 'USD/CAD', price: 1.3318, change: '-0.0012', pChange: '-0.0915%', dayRange: '1.3305 - 1.3337', weekRange: '1.2461 - 1.3598', imageUrl: '', favorite: false},
      {id: 18, name: 'USD/CHF', price: 1.0035, change: '-0.0017', pChange: '-0.1701%', dayRange: '1.0022 - 1.0060', weekRange: '0.9443 - 1.0332', imageUrl: '', favorite: false}
    ];

    let currenciesCatalog: Currency[] = [
      {id: 11, name: 'EUR/USD', price: 1.0622, change: '+0.0005', pChange: '+0.0509%', dayRange: '1.0604 - 1.0630', weekRange: '1.0540 - 1.1707', imageUrl: '', favorite: false},
      {id: 12, name: 'AUD/USD', price: 0.7574, change: '+0.0005', pChange: '+0.0674%', dayRange: '0.7555 - 0.7582', weekRange: '0.6828 - 0.7834', imageUrl: '', favorite: false},
      {id: 13, name: 'GBP/USD', price: 1.2527, change: '+0.0021', pChange: '+0.1671%', dayRange: '1.2498 - 1.2534', weekRange: '1.2498 - 1.5817', imageUrl: '', favorite: false},
      {id: 14, name: 'USD/JPY', price: 108.6370, change: '-0.4720', pChange: '-0.4326%', dayRange: '108.5730 - 109.2260', weekRange: '99.5730 - 118.6470', imageUrl: '', favorite: false},
      {id: 15, name: 'EUR/JPY', price: 115.3920, change: '-0.4610', pChange: '-0.3979%', dayRange: '115.3290 - 116.0170', weekRange: '109.5852 - 139.3154', imageUrl: '', favorite: false},
      {id: 16, name: 'EUR/GBP', price: 0.8478, change: '-0.0010', pChange: '-0.1225%', dayRange: '0.8472 - 0.8495', weekRange: '0.6936 - 0.8495', imageUrl: '', favorite: false},
      {id: 17, name: 'USD/CAD', price: 1.3318, change: '-0.0012', pChange: '-0.0915%', dayRange: '1.3305 - 1.3337', weekRange: '1.2461 - 1.3598', imageUrl: '', favorite: false},
      {id: 18, name: 'USD/CHF', price: 1.0035, change: '-0.0017', pChange: '-0.1701%', dayRange: '1.0022 - 1.0060', weekRange: '0.9443 - 1.0332', imageUrl: '', favorite: false}
    ];
    return {currencies, currenciesCatalog};
  }
}
