import { Pipe, PipeTransform } from '@angular/core';

import { Currency } from './currency';

@Pipe({
  name: 'currencyFilter'
})
export class CurrencyFilterPipe implements PipeTransform {

  transform(values: Currency[], filterByName: string, filterByFavorite: string): Currency[] {

     const filterByNameUpper = filterByName ? filterByName.toLocaleUpperCase() : null;
     return filterByNameUpper || filterByFavorite === 'favorite' ?
      values.filter((item: Currency) => {
        if (filterByNameUpper && filterByFavorite  === 'favorite') {
          return item.name.includes(filterByNameUpper) && item.favorite;
        } else if (filterByNameUpper) {
          return item.name.includes(filterByNameUpper);
        } else {
          return item.favorite;
        }
      }) : values;

     //const filterByUpper = filterBy ? filterBy.toLocaleUpperCase() : null;
     //return filterByUpper ? values.filter(item => item.name.includes(filterByUpper)) : values;
  }

}
