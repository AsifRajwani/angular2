import { Component, OnInit, ViewChild, AfterViewChecked } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { Location }               from '@angular/common';
import { NgForm } from '@angular/forms';

import 'rxjs/add/operator/switchMap';

import { Currency } from '../shared/currency';
import { CurrencyService } from '../shared/currency.service';

@Component({
  selector: 'app-currency',
  templateUrl: './currency.component.html',
  styleUrls: ['./currency.component.css']
})
export class CurrencyComponent implements OnInit {
  title: string = 'Currency';
  currency: Currency;
  currencyForm: NgForm;
  @ViewChild('currencyForm') currentForm: NgForm;

  constructor(
    private currencyService: CurrencyService,
    private route: ActivatedRoute,
    private location: Location
  ) {}

  ngOnInit() {
    this.route.params
      .switchMap((params: Params) => this.currencyService.getCurrency(+params['id']))
        .subscribe(currency => this.currency = currency);
  }

  ngAfterViewChecked() {
    if (this.currentForm === this.currencyForm) {
      return;
    }
   this.currencyForm = this.currentForm;
   if (this.currencyForm) {
       this.currencyForm.valueChanges
         .subscribe(data => this.onValueChanged(data));
    }
  }
//https://angular.io/docs/ts/latest/cookbook/form-validation.html
/*
  formErrors = {
    'name': '',
    'power': ''
  };
  validationMessages = {
    'name': {
      'required':      'Name is required.',
      'minlength':     'Name must be at least 4 characters long.',
      'maxlength':     'Name cannot be more than 24 characters long.',
      'forbiddenName': 'Someone named "Bob" cannot be a hero.'
    },
    'power': {
      'required': 'Power is required.'
    }
  };
  */
  onValueChanged(data?: any) {

    if (!this.currencyForm) {
      return;
    }
    const form = this.currencyForm.form;

    /*
    for (const field in this.formErrors) {
      // clear previous error message (if any)
      this.formErrors[field] = '';
      const control = form.get(field);

      if (control && control.dirty && !control.valid) {
        const messages = this.validationMessages[field];
        for (const key in control.errors) {
          this.formErrors[field] += messages[key] + ' ';
        }
      }
    }
    */
  }

  save(): void {
    this.currencyService.update(this.currency)
      .then(() => this.goBack());
  }

  delete(): void {
    this.currencyService.delete(this.currency.id)
      .then(() => this.goBack());
  }

  goBack(): void {
    if (this.currencyForm && this.currencyForm.dirty) {
      const answer = confirm('You have not saved the changes. Do you want to save changes?');
      if (answer) {
        this.save();
      } else {
        this.location.back();
      }
    } else {
      this.location.back();
    }
  }

}
