import { TestBed, inject } from '@angular/core/testing';

import { CurrencySearchService } from './currency-search.service';

describe('CurrencySearchService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CurrencySearchService]
    });
  });

  it('should ...', inject([CurrencySearchService], (service: CurrencySearchService) => {
    expect(service).toBeTruthy();
  }));
});
