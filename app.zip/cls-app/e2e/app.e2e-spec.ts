import { ClsAppPage } from './app.po';

describe('cls-app App', () => {
  let page: ClsAppPage;

  beforeEach(() => {
    page = new ClsAppPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
