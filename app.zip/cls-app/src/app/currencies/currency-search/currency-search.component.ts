import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Observable }        from 'rxjs/Observable';
import { Subject }           from 'rxjs/Subject';

// Observable class extensions
import 'rxjs/add/observable/of';

// Observable operators
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';

import { CurrencySearchService } from '../shared/currency-search.service';
import { CurrencyService } from '../shared/currency.service';
import { Currency } from '../shared/currency';

@Component({
  selector: 'app-currency-search',
  templateUrl: './currency-search.component.html',
  styleUrls: ['./currency-search.component.css']
})
export class CurrencySearchComponent implements OnInit {
  //@Input() addCurrency: function;
  currencies: Observable<Currency[]>;
  private searchTerms = new Subject<string>();
  title: string = 'Search Currency Pair';
  @Output() onCurrencyAdded = new EventEmitter<boolean>();

  constructor(private currencySearchService: CurrencySearchService,
    private currencyService: CurrencyService) { }

  ngOnInit() {
    this.currencies = this.searchTerms
      .debounceTime(300)        // wait 300ms after each keystroke before considering the term
      .distinctUntilChanged()   // ignore if next search term is same as previous
      .switchMap(term => term   // switch to new observable each time the term changes
        // return the http search observable
        ? this.currencySearchService.search(term)
        // or the observable of empty currencies if there was no search term
        : Observable.of<Currency[]>([]))
      .catch(error => {
        // TODO: add real error handling
        console.log(error);
        return Observable.of<Currency[]>([]);
      });
  }
  // Push a search term into the observable stream.
  search(term: string): void {
    this.searchTerms.next(term);
  }

  addCurrency(currency: Currency):void {
    //let addCurrency: boolean = false;
    if (currency.id) {
      this.currencyService.getCurrency(currency.id).
      then((foundCurrency) => {
        // the Currency exist here, that check is not needed if API behaves correctly
        if (foundCurrency) {
          alert(`${foundCurrency.name} already in the Currency List!`);
        }
      }).
      catch((error) => {
        if (error.status === 404) {
          // Currency not in the lsit
          const addCurrency = true;
          return addCurrency;
        } else {
          // TODO: add real error handling
          console.log(error);
        }
      }).then((addCurrency) => {
        if (addCurrency) {
            //delete currency.id;
            return this.currencyService.create(currency);
        }
      }).
      then((currency) => {
        this.onCurrencyAdded.emit(true);
        alert(`${currency.name} was added to the Currency List!`);
      }).
      catch((error) => {
          // TODO: add real error handling
          console.log(error);
      });
    }
  }

}
